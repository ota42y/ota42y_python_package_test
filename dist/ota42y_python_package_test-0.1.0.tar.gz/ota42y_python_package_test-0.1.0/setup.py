# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ota42y_python_package_test']

package_data = \
{'': ['*']}

install_requires = \
['absl-py @ '
 'git+https://github.com/abseil/abseil-py.git@c99edd8e3dffe3667a9f086db86aa259927ac429']

setup_kwargs = {
    'name': 'ota42y-python-package-test',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'ota42y',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/ota42y/ota42y_python_package_test',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
